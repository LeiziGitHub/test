//
//  main.m
//  ForwardAlertDemo
//
//  Created by Lester on 16/9/12.
//  Copyright © 2016年 Lester-iOS开发:98787555. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
